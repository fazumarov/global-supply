Corrected Global Supply clothing set

Source: the original 2-page clothing catalog provided in chat.
Total products: 60

Pricing:
- Hoodies: $70
- Sweatpants/pants: $70
- T-shirts: $50
- Long sleeves / raglans: $50
- Shorts: $50
- No bulk pricing

Files:
- public/clothing-corrected/ : 60 clean PNG product images extracted from the original catalog
- corrected-clothing-products.ts : ready-to-paste product entries
- clothing-map.csv : page/row/column mapping used for verification

Recommended project path:
Copy public/clothing-corrected into your project's public folder.
Then replace the old clothing entries in app/lib/products.ts with the entries from corrected-clothing-products.ts.
